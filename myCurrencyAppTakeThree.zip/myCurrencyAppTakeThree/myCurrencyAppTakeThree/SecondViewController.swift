//
//  SecondViewController.swift
//  myCurrencyAppTakeThree
//
//  Created by Anastasia Athans-Stothoff on 6/12/20.
//  Copyright © 2020 Anastasia Athans-Stothoff. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet var labelGreekDrachma: UILabel!
    
    var receivingString = ""
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        labelGreekDrachma.text = receivingString
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
