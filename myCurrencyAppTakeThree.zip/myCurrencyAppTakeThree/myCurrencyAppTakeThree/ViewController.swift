//
//  ViewController.swift
//  myCurrencyAppTakeThree
//
//  Created by Anastasia Athans-Stothoff on 6/12/20.
//  Copyright © 2020 Anastasia Athans-Stothoff. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        performSegue(withIdentifier: "Pez1", sender: self)
          
    func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        performSegue(withIdentifier: "Pez2", sender: self)
    
    func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        performSegue(withIdentifier: "Pez3", sender: self)
    
   func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        performSegue(withIdentifier: "Pez4", sender: self)
             
}

}

}
}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let nextVC = segue.destination as! SecondViewController
        nextVC.navigationItem.title = "Please enjoy your Greek Drachmas"
        nextVC.receivingString = "Greek Drachma"
  
        func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let nextVC = segue.destination as! ThirdViewController
            nextVC.navigationItem.title = "Please enjoy your Thai Bahts"
            nextVC.receivingString = "Thai Baht"
    
        func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let nextVC = segue.destination as! FourthViewController
            nextVC.navigationItem.title = "Please enjoy your British Pounds"
            nextVC.receivingString = "British Pound"
            
    
    
    
    
    }
}
}
}
